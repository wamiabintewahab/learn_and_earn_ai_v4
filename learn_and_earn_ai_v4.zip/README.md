# Learn and Earn AI — Version 0.4

## What changed
This version has a more conventional website structure:
- **Home** — overview and clear next steps
- **Learn** — three beginner lesson cards
- **Coding Playground** — editor, Run code, Reset example, output and errors
- **About** — vision, principles, what exists and what is not implemented

The navigation switches between these sections, and the page uses a new light teal / white / navy palette.

## Open locally
1. Download and extract the ZIP.
2. Open `index.html` in a modern browser.
3. Use the navigation at the top: Home, Learn, Coding Playground, About.
4. In Coding Playground, press **Run code** and then try **Reset example**.

## Current limitations
This is a static front-end prototype with a small, restricted educational interpreter. It has no AI, backend, user accounts, cloud saving, social sign-in, payments, or full custom programming language. The demo code is processed locally in the browser. It is not a production-ready service yet.

## Publish using GitHub Pages
1. If you do not already have one, create a GitHub account at https://github.com/.
2. Create a new repository. A suggested name is `learn-and-earn-ai`.
3. Choose Public if you want the source to be visible and the public demo accessible through Pages. Do not upload secrets, passwords, API keys, or private information.
4. Upload the contents of this folder to the repository root. Make sure `index.html` is at the top level, not buried in another folder.
5. In the repository, go to **Settings → Pages**.
6. Under the build/deployment section, select **Deploy from a branch**, choose `main` and `/(root)`, then Save.
7. Wait for the deployment to finish. Open the URL shown in the Pages section and test Home, Learn, Coding Playground, Run, Reset, and mobile layout.

GitHub Pages serves static websites. If you later add accounts, cloud saves, or a database, you will need a properly designed backend or trusted service, plus security and privacy testing. A button alone does not make those features functional.
